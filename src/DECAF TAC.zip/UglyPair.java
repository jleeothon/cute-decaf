
public class UglyPair<V, W> {
	V v;
	W w;
	public UglyPair(V v, W w) {
		this.v = v;
		this.w = w;
	}
}
