
public class UglyTriplet<V, W, X> {

	V v;
	W w;
	X x;

	public UglyTriplet(V v, W w, X x) {
		this.v = v;
		this.w = w;
		this.x = x;
	}

}