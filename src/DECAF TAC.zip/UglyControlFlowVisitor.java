
/**
  * Please, remove functionality from <c>UglySymbolTableVisitor</c>. Bring it 'ere. Plis.
  * Plis, plis, plis =3.
  */
public class UglyControlFlowVisitor /* implements CuteDecafVisitor */ {
}